function loginValidation() {
    var useremail = document.registration.username;
    var userpassword = document.registration.password;

    var emailValid = emailValidation(useremail);
    var passwordValid = passwordValidation(userpassword, 7, 12);

    if (emailValid && passwordValid) {
        window.location.href = "home.html"; 
        return false; 
    }

    return false;
}

function emailValidation(useremail) {
    var email_expression = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (useremail.value.match(email_expression)) {
        document.getElementById("usernameError").textContent = "";
        return true;
    }
    document.getElementById("usernameError").textContent = "Enter a proper email.";
    return false;
}

function passwordValidation(userpassword, mx, my) {
    var passid_len = userpassword.value.length;
    if (passid_len == 0 || passid_len >= my || passid_len < mx) {
        document.getElementById("passwordError").textContent = "Password should be between " + mx + " to " + my + " characters.";
        return false;
    }
    document.getElementById("passwordError").textContent = "";
    return true;
}


function registerValidation() {



    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('pw').value;
    var confirmPassword = document.getElementById('cpw').value;
    var country = document.getElementById('contry').value;
    var passportYes = document.getElementById('passportYes').checked;
    var passportNo = document.getElementById('passportNo').checked;
    var agreeToTerms = document.getElementById('cb').checked;

    var isValid = true;

    
    if (name === '') {
        alert('Name is required.');
        isValid = false;
    }

    
    if (email === '') {
        alert('Email is required.');
        isValid = false;
    }

   
    if (password === '') {
        alert('Password is required.');
        isValid = false;
    } else if (password !== confirmPassword) {
        alert('Passwords do not match.');
        isValid = false;
    }

  
    if (country === '') {
        alert('Please select a country.');
        isValid = false;
    }


    if (!passportYes && !passportNo) {
        alert('Please indicate if you have a passport.');
        isValid = false;
    }

    if (!agreeToTerms) {
        alert('You must agree to the terms and conditions.');
        isValid = false;
    }

    if (isValid) {
        alert('Registration successful!');
        

    }

    return isValid;
}



function validateForm() {
    var username = document.getElementById('username').value;
    var age = document.getElementById('age').value;
    var pincode = document.getElementById('pincode').value;
    var pan = document.getElementById('pan').value;
    var password = document.getElementById('password').value;
    var phone = document.getElementById('phone').value;
  
    var isValid = true;
  
    // Username validation
    if (username.length < 8 || username.length > 10) {
      document.getElementById('usernameError').textContent = "Username must be between 8 and 10 characters";
      isValid = false;
    } else {
      document.getElementById('usernameError').textContent = "";
    }
  
    // Age validation
    if (age<0||age < 1 || age > 100 || isNaN(age)) {
    document.getElementById('ageError').textContent = "Age must be between 1 and 100.";
    isValid = false;
  } else {
    document.getElementById('ageError').textContent = "";
  }
  
    // Pincode validation
    if (!/^\d{6}$/.test(pincode)) {
      document.getElementById('pincodeError').textContent = "Pincode must be 6 digits";
      isValid = false;
    } else {
      document.getElementById('pincodeError').textContent = "";
    }
  
    // PAN number validation
    if (!/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan)) {
      document.getElementById('panError').textContent = "PAN number must be 10 characters alphanumeric";
      isValid = false;
    } else {
      document.getElementById('panError').textContent = "";
    }
  
    // Password validation
    if (!/(?=.[A-Z])(?=.[!@#$%^&])(?=.[0-9]).{10}/.test(password)) {
      document.getElementById('passwordError').textContent = "Password must have 1 uppercase, 1 special character, 1 digit, and be 10 characters long";
      isValid = false;
    } else {
      document.getElementById('passwordError').textContent = "";
    }
  
    // Phone number validation
    if (!/^8\d{9}$/.test(phone)) {
      document.getElementById('phoneError').textContent = "Phone number must start with 8 and be 10 digits long";
      isValid = false;
    } else {
      document.getElementById('phoneError').textContent = "";
    }
  
    return isValid;
  }